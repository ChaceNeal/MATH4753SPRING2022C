#' FIREDAM Data Set.
#'
#' 6 lines of data for fire damage.
#'
#' @format A data set with 2 rows and 15
#' variables:
#' \describe{
#'   \item{DISTANCE}{distance, in miles}
#'   \item{DAMAGE}{damage of the fire, in percentage of structure damaged}
#'   ...
#' }
#' @source Text Book
"FIREDAM"
