#' My Sample Function
#'
#' @param n number of sample
#' @param iter is iteration
#' @param time is time thats passed
#'
#' @return sample
#' @export
#'
#' @examples
#' \dontrun{mysample(n, iter=10,time=0.5)}
mysample=function(n, iter=10,time=0.5){
for( i in 1:iter){
s=sample(1:10,n,replace=TRUE)
}
}
